import axios from "axios"
import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"

function Teacherlist() {
    const { name } = useParams()
    const [data, setData] = useState([]);
    const [show, setshow] = useState(true)

    useEffect(() => {
        axios.get(`http://localhost:3000/teacher`)
            .then((res) => {
                setData(res.data);
            })
            .catch((err) => {
                console.log(err);
            });
    }, []);
    return <div>
        <h1>welcome to {name}</h1>
        <button>Checkin</button>
        <button>Apply Leave</button>
        <div>
            <div>
                {show &&
                    data.filter((ele) => ele.name === name).map((teacher) => (
                        <div key={teacher.id}>
                            <h6>Name : {teacher.name}</h6>
                            <h6>Age : {teacher.age}</h6>
                            <h6>GENDER : {teacher.gender}</h6>
                            <h6>Dob : {teacher.dob}</h6>
                            <h6>Experince : {teacher.experince}</h6>
                            <h6>QUALIFICATION : {teacher.qualificatton}</h6>
                            <h6>Major : {teacher.major}</h6> 
                            <h6>Role : {teacher.role}</h6>
                            <h6>Mobile no : {teacher.mobile}</h6>
                            <h6>Email : {teacher.mail}</h6>
                            <h6>ADDRESS : {teacher.adrss}</h6>
                        </div>
                    ))}
            </div>
        </div>
    </div>
}
export default Teacherlist