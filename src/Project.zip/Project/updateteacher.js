
import { useState, useEffect } from 'react';


import axios from 'axios';
import { useParams } from 'react-router-dom';
function Updateteacher() {
  const [data, setdata] = useState({
    name: '',
    age: '',
    dob: '',
    Qualification: '',
    gender: '',
    mail: '',
    adrss: ''
  });

  const { id } = useParams();

  useEffect(() => {
    axios.get(`http://localhost:3000/teacher/${id}`)
      .then((response) => {
        setdata(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const handleUpdate = () => {
    axios.put(`http://localhost:3000/teacher/${id}`, data)
      .then((response) => {
        console.log('Update successful:', response.data);
      })
      .catch((error) => {
        console.error('Update failed:', error);
      });
  };

  return (
    <div>
      <div id='updateteacher'>
        <h1>UPDATE TEACHER</h1>
        <form>
          <h5>Name: <input name="name" value={data.name} onChange={(e) => setdata({...data, [e.target.name]: e.target.value})} type="text" placeholder="ENTER THE NAME" /></h5>
          <h5>Age: <input name="age" value={data.age} onChange={(e) => setdata({...data, [e.target.name]: e.target.value})} type="number" placeholder="ENTER YOUR AGE" /></h5>
          <h5>DOB: <input name="dob" value={data.dob} onChange={(e) => setdata({...data, [e.target.name]: e.target.value})} type="date" placeholder="ENTER YOUR DATE OF BIRTH" /></h5>
          <h5>Qualification: <input name="Qualification" type='text' value={data.Qualification} onChange={(e) => setdata({...data, [e.target.name]: e.target.value})} /></h5>
          <h5>Gender:
            <select name="gender" id='updateselect' value={data.gender} onChange={(e) => setdata({...data, [e.target.name]: e.target.value})}>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </h5>
          <h5>Email: <input name="mail" value={data.mail} onChange={(e) => setdata({...data, [e.target.name]: e.target.value})} type="email" placeholder="ENTER THE EMAIL" /></h5>
          <h5>Address:</h5>
          <textarea name="adrss" id='updateadres' value={data.adrss}
           onChange={(e) => setdata(
            {...data, [e.target.name]: e.target.value}
            )}></textarea>
        </form>
        <button onClick={handleUpdate}>submit</button>
      </div>
    </div>
  );
}

export default Updateteacher