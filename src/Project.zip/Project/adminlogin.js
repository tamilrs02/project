import '../Project/adminlogin.css'
import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Adminlogin() {
    const [data, setdata] = useState([]);
    const adminnavigate = useNavigate()
    useEffect(() => {
        axios.get("http://localhost:3000/admin")
            .then((res) => {
                setdata(res.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);

    const adminbtn = () => {
        let Adminname = document.getElementById('adminname');
        let Adminpassword = document.getElementById('adminpassword');
        const Invalid = data.find((ele) => ele.name === Adminname.value && ele.DOB === Adminpassword.value);
        if (Invalid) {
            console.log('passed');
            adminnavigate("Pageadmin/" + Adminname.value)
        } else {
            console.log('failed');
        }
    }

    return <div id='pagelogin'>
        <div className="background">
            <div className="shape"></div>
            <div className="shape"></div>
        </div>
        <form className='formlogin'>
            <h2>GANI ACADEMY</h2>
            <h3>Login Here</h3>
            <label for="username">Username</label>
            <h4>Username  <input id='adminname'></input></h4>
            <label for="password">Password</label>
            <h4>Password  <input id='adminpassword' type="date"></input></h4>
            <button onClick={adminbtn}>Login</button>
        </form>
    </div>

}
export default Adminlogin