import axios from "axios";
import { useState } from "react";
import './addstd.css'
import { useNavigate, useParams } from "react-router-dom";

function Addteacher() {
  const [data, setdata] = useState("");
  const [name, setname] = useState("");
  const [error, seterror] = useState(false)
  const [age, setAge] = useState("");
  const [dob, setDob] = useState("");
  const [experince, setExperince] = useState("");
  const [qualificatton, setQualificatton] = useState("");
  const [role, setRole] = useState("");
  const [major, setMajor] = useState("");
  const [gender, setGender] = useState("");
  const [mobile, setMobile] = useState("");
  const [mail, setMail] = useState("");
  const [adrss, setAdrss] = useState(" ");
  const { adminname } = useParams()

  const submit = () => {

    if (
      name.trim() !== "" &&
      age.trim() !== "" &&
      dob.trim() !== "" &&
      experince.trim() !== "" &&
      role.trim() !== "" &&
      major.trim() !== "" &&
      qualificatton.trim() !== "" &&
      gender.trim() !== "" &&
      mobile.trim() !== "" &&
      mail.trim() !== "" &&
      adrss.trim() !== ""
    ) {
      axios
        .post("http://localhost:3000/teacher", {
          name,
          age,
          dob,
          role,
          major,
          mobile,
          mail,
          experince,
          qualificatton,
          gender,
          adrss,
        })
        .then((res) => {
          setdata(res.data);
          console.log('true');
        })
        .catch((err) => {
          console.log(err);
        });

      seterror("");
      setname("");
      setDob("");
      setAge("");
      setGender("");
      setMobile("");
      setMail("");
      setRole("");
      setMajor("");
      setAdrss("");
      setExperince("");
      setQualificatton("");
      naviback(`/Adminlogin/Pageadmin/` + adminname);

    } else {
      seterror("Please fill in all fields.");
      console.log('false');

    }
  };
  const naviback = useNavigate();



  return (
    <div id="addtecher" >
      <div className="form">
        <h1>ADD TEACHER</h1>
        <form>
          <h5>
            Name:
            <input
              type="text" placeholder="ENTER THE NAME"
              value={name}
              onChange={(e) => setname(e.target.value)}
            ></input>
          </h5>

          <h5>
            Age:
            <input
              type="number" placeholder="ENTER YOUR AGE"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            ></input>
          </h5>
          <h5>
            Gender:
            <select value={gender} onChange={(e) => setGender(e.target.value)}>
              <option value="male">male</option>
              <option value="female">Female</option>
              <option value="male">male</option>
              <option value="other">Other</option>
            </select>
          </h5>
          <h5>
            DOB:
            <input
              type="date" placeholder="ENTER YOUR DATEOF BIRTH"
              value={dob}
              onChange={(e) => setDob(e.target.value)}
            ></input>
          </h5>
          <h5>
            Experince:
            <input
              type="number" placeholder="ENTER YOUR EXPERINCE"
              value={experince}
              onChange={(e) => setExperince(e.target.value)}
            ></input>
          </h5>
          <h5>
            Qualificatton:
            <input
              type="text" placeholder="ENTER THE NAME"
              value={qualificatton}
              onChange={(e) => setQualificatton(e.target.value)}
            ></input>
          </h5>
          <h5>
            Major:
            <input
              type="text" placeholder="ENTER YOUR MAJOR"
              value={major}
              onChange={(e) => setMajor(e.target.value)}
            ></input>
          </h5>
          <h5>
            Role :
            <input
              type="text" placeholder="ENTER YOUR ROLE"
              value={role}
              onChange={(e) => setRole(e.target.value)}
            ></input>
          </h5>
          <h5>
            Mobile No:
            <input
              type="number" placeholder="ENTER YOUR MOBILE NO"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
            ></input>
          </h5>
          <h5>
            Email:
            <input
              type="email" placeholder="ENTER THE EMAIL"
              value={mail}
              onChange={(e) => setMail(e.target.value)}
            ></input>
          </h5>
          <h5>Address:</h5>
          <textarea
            id="myTextarea"
            name="myTextarea"
            rows="4"
            cols="50"
            value={adrss}
            onChange={(e) => setAdrss(e.target.value)}
          ></textarea>
        </form>
        <h4 className="text-center">{error && <h6>Please fill in all fields.</h6>}</h4>
        <button onClick={submit}>Submit</button>

      </div>

    </div>

  );
}

export default Addteacher