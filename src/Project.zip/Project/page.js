import Home from "./mainpage";
function Page(){
    return <div>
        <Home/>
    </div>
}
export default Page