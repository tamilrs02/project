import { useEffect, useState } from 'react';
import './std.css'
import axios from 'axios';

import { useNavigate } from 'react-router-dom';

function Teacherlogin() {
    const [data, setdata] = useState([]);
    const [error, seterror] = useState(false)
    const adminnavigate = useNavigate()
    useEffect(() => {
        axios.get("  http://localhost:3000/teacher")
            .then((res) => {
                setdata(res.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);
    const adminbtn = () => {
        let Adminname = document.getElementById('user');
        let Adminpassword = document.getElementById('pass');
        const Invalid = data.find((ele) => ele.name === Adminname.value && ele.dob === Adminpassword.value);
        if (Invalid) {
            console.log('passed');
            adminnavigate('/Teacherlist/' + Adminname.value)
        } else {
            console.log('failed');
            seterror(true)
        }
    }
    return <div id='main'>

        <div className='login'>
            <h2>GANI ACADEMY</h2>
            <h3>Hi Teacher !</h3>
            <h4>Username : <input id='user'></input></h4>
            <h4>Password : <input type="date" id='pass'></input></h4>
            <h3>{error && <h5>invailed the corect username ,password</h5>}</h3>
            <button onClick={adminbtn} className="btn">Login</button>
        </div>



    </div>




}
export default Teacherlogin