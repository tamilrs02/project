function Alumuni(props){
    return <div>
        <img src={props.image} alt="furn"/>
        <h5>{props.name}</h5>
        <h5>{props.price}</h5>
    </div>
}
export default Alumuni