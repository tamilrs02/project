
import t1 from './project img/team-1.jpg'
import Alumuni from './alumuni'
function Alumuniprops() {
    return <>
        <div className='cart'>
            <PropsAlumuniprops
                name='BROWN CHAIR DESIGN'
                price='100'
                image={t1}
            />
        </div>
    </>
}
export default Alumuniprops